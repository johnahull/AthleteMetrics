function n(n){const t=20.45/n;return Math.round(10*t)/10}function t(t){return`${t}s (${n(t)} mph)`}export{n as c,t as f};
