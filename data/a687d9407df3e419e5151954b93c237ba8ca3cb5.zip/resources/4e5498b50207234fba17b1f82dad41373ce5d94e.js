import{u as t,a as r}from"./vendor-router-CfFYDTfF.js";function e(){const[,e]=t();return r.useEffect(()=>{e("/data-entry?tab=import",{replace:!0})},[e]),null}export{e as default};
