---
name: "Feature request"
about: "Propose a user-facing outcome"
title: "[feat] <short outcome>"
labels: ["type:feature"]
assignees: []
---

## Problem
<!-- User problem in one sentence -->

## Outcome
<!-- What success looks like for the user -->

## Acceptance Criteria
- [ ] 

## Non-Goals
- 

## Size
<!-- S / M / L -->
